# Python Data Structures Q and A

## Lists
## Tuples
## Dictionaries
## Sets
## Collections

## What is the difference between list and tuple?
* List is mutable while tuple is not. Tuple can be hashed as index/key 
  in dictionaries.

## In Python what is slicing?
* A mechanism to select a range of items from sequence types like list, 
  tuple, strings etc. is known as slicing.

>>>>## What is Dict and List comprehensions are?
* They are syntax constructions to ease the creation of a Dictionary or List 
  based on existing iterable.

## Whats the difference between append() and extend() methods.?
* append(Single-Element), adds element at the end of the list.
* extend(Another-List), Appends Another-List at the end of the current list.
